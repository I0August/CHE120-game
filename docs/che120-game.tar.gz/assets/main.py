import pygame
import asyncio

pygame.init()

screen = pygame.display.set_mode((800, 600))
pygame.display.set_caption("CHE120 Game")

clock = pygame.time.Clock()

x = 400
y = 300

async def main():
    global x

    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        keys = pygame.key.get_pressed()

        if keys[pygame.K_LEFT]:
            x -= 5

        if keys[pygame.K_RIGHT]:
            x += 5

        screen.fill((255, 255, 255))

        pygame.draw.circle(
            screen,
            (0, 100, 255),
            (x, y),
            40
        )

        pygame.display.flip()
        clock.tick(60)

        # Important for pygbag
        await asyncio.sleep(0)

pygame.quit()

asyncio.run(main())
